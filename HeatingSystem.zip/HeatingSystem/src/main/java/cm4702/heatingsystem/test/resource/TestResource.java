package cm4702.heatingsystem.test.resource;

//JAX-RS
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;

/**
 * This is a dummy resource class to test a simple GET request.
 * @author K. Hui
 *
 */
@Path("/test")
public class TestResource
{
/**
 * This method handles a GET request to the URL "/heatingsystem/api/test".
 * @return A simple text response.
 */
@GET
@Produces(MediaType.TEXT_PLAIN)
public Response dummyGet()
{
return Response.status(200).entity("Congratulations! Jersey is working!").build();
} //end method
} //end class

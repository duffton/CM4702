package cm4702.heatingsystem.exception;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;

/**
 * This subclass customises the WebApplicationException to report an invalid parameter.
 * @author Ayla Duffton.
 *
 */
public class InvalidParamException extends WebApplicationException 
{
/**
 * Creates an InvalidParamException object.
 * @param message The message to include in the reply.
 */
public InvalidParamException(String message)
{
super(Response.status(Response.Status.BAD_REQUEST).entity(message).type("text/plain").build());
} //end method
} //end class

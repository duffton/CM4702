package cm4702.heatingsystem.exception;

import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;

/**
 * This subclass customises the WebApplicationException to report an unknown city to be found.
 * @author Ayla Duffton
 *
 */
public class RoomNotFoundException extends WebApplicationException
{
/**
 * Creates a RoomNotFoundException. 
 * @param name The room name.
 */
public RoomNotFoundException(String name)
{
super(Response.status(Response.Status.NOT_FOUND).entity("room name "+name+" not found").type("text/plain").build());
} //end method
} //end class

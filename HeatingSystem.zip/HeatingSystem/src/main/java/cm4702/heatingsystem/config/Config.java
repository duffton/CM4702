package cm4702.heatingsystem.config;

// Amazon SDK import.
import software.amazon.awssdk.regions.Region;

/**
 * This class defines some constants.
 * @author Ayla Duffton.
 *
 */
public class Config
{
/**
 * The region of DynamoDB service to connect.
 */
public static final Region REGION=Region.EU_WEST_1;

/**
 *Local DynamoDB server connection end-point URL.
 */
public static final String LOCAL_ENDPOINT="http://localhost:8000";
// public static final String LOCAL_ENDPOINT=null;

/**
 *The DynamoDB table name. 
 */
// public static final String TABLE_NAME="cm4702-heatingsystem-room";
public static final String TABLE_NAME="heatingsystem-room";
} //end class

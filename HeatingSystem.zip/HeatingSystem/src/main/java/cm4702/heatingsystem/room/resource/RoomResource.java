package cm4702.heatingsystem.room.resource;

// Java imports.
import java.security.InvalidParameterException;
import java.util.*;
import java.util.stream.Collectors;

// Jersey imports.
import jakarta.ws.rs.*;
import jakarta.ws.rs.core.*;

// DynamoDB imports.
import software.amazon.awssdk.enhanced.dynamodb.*;
import software.amazon.awssdk.services.dynamodb.model.DynamoDbException;
import cm4702.aws.util.*;

// CM4702 Package imports.
import cm4702.heatingsystem.config.*;
import cm4702.heatingsystem.exception.*;
import cm4702.heatingsystem.room.model.*;

/**
 * This RoomResource class handles requests to the URL pattern "/heatingsystem/api/room".
 * @author Ayla Duffton
 */
@Path("/room")
public class RoomResource
{
/**
 * This method handles a POST request to the URL "/heatingsystem/api/room" to store a Room object into DynamoDB.
 * @param name - The room unique code.
 * @param temperature - The room temperature.
 * @return - A response with the request.
 */
@POST
@Produces(MediaType.TEXT_PLAIN)
public Response addRoom(@FormParam("name") String name,	
						@FormParam("temperature") Double temperature)		
{
try	{
	
	// Checking temperature value at the start of the method.
	System.out.println("** Temperature at start of method: **" + temperature);
	Room room=new Room(name,temperature);
	
	// Checking variable values after the Room object creation.
	System.out.println("** Variable values after new Room is created and parameters sent **");	
	System.out.println(name);
	System.out.println(temperature);
	System.out.println(room.toString());
	
	DynamoDbEnhancedClient eClient=DynamoDbUtil.getEClient(null, "http://localhost:8000");
	
	String tableName="heatingsystem-room";
	DynamoDbTable<Room> table=eClient.table(tableName,TableSchema.fromBean(Room.class));
	
	// Adds room to table.
	table.putItem(room);
	
	// 200 response that room and temperature stored successfully.
	return Response.
			status(201).
			entity(room+" ("+temperature+") saved sucessfully").
			build();
	} catch (Exception e)
		{
		System.out.println(e);
		// 400 response if there is an error.
		return Response.
				status(400).
				entity("Something went wrong. Parameters accepted: name, temperature,").
				build();
		}
} //end method

/**
 * This method handles a GET request to the URL pattern "/heatingsystem/api/room/{room name}"
 * to retrieve a room's information and return it as a JSON map.
 * 
 * @param code - The room name.
 * @return	- The Room object retrieved using the given name.  This Room object will be converted to JSON by Jackson.
 */
@GET
@Path("/{room}")
@Produces(MediaType.APPLICATION_JSON)
public Room retrieveOneRoom(@PathParam("name") String name)
{
		DynamoDbEnhancedClient eClient=DynamoDbUtil.getEClient(Config.REGION,Config.LOCAL_ENDPOINT);
		
		DynamoDbTable<Room> roomTable=eClient.table(Config.TABLE_NAME,TableSchema.fromBean(Room.class));
		Key key=Key.builder().partitionValue(name).build();
		Room room=roomTable.getItem(key);
		if (room!=null)
			return room;
		
		// Exception if room not found.
		throw new RoomNotFoundException(name);

		// Alternative exception option.
		//throw new WebApplicationException("Unknown city code: "+code,404);
	
} //end method

/**
 * This method handles a GET request to the URL "/heatingsystem/api/room"
 * to retrieve all rooms as a JSON list.
 * * @return A Collection<Room> object. This will be converted to a JSON list by Jackson.
 */
@GET
@Produces(MediaType.APPLICATION_JSON)
public Collection<Room> retrieveAllRooms()
{

	try	{
		DynamoDbEnhancedClient eClient=DynamoDbUtil.getEClient(Config.REGION,Config.LOCAL_ENDPOINT);
		DynamoDbTable<Room> roomTable=eClient.table(Config.TABLE_NAME,TableSchema.fromBean(Room.class));
		List<Room> rooms=roomTable.scan().items().stream().collect(Collectors.toList());
		return rooms;
		} catch (Exception e)
			{
			throw new WebApplicationException(e.toString(),500);
			}
	} //end method
	
} //end class

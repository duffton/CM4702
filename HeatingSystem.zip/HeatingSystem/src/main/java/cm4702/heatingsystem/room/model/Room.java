package cm4702.heatingsystem.room.model;

import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.*;

/**
 * This class models a room.
 * @author Ayla Duffton.
 */
@DynamoDbBean
public class Room
{

/**
 * The name of the room.
 */
public String name;

/**
 * The temperature of the room.
 */
public double temperature;

/**
 * Default constructor for AWS SDK.
 */
public Room()
{
} //end method

/**
 * Creates a Room object.
 * @param name	The Room name.
 * @param temperature The room temperature.
 */
public Room(String name, double temperature)
{
// Setters for AWS SDK.
this.setName(name);
this.setTemperature(temperature);
} //end method

/**
 * Return the room name.
 * @return	The unique room name.
 */
@DynamoDbPartitionKey
public String getName()
{
return this.name;
} //end method

/**
 * Return the room temperature.
 * @return	The room temperature.
 */

@DynamoDbAttribute(value="temperature")
public double getTemperature()
{
return this.temperature;
} //end method

/**
 * Set the room name.
 * @param name The room name.
 */
public void setName(String name)
{
this.name = name;
} //end method

/**
 * Set the room temperature.
 * @param temperature The room temperature.
 */
public void setTemperature(double temperature)
{
this.temperature = temperature;
} //end method

} //end class

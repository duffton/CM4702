module mqtt {
	requires org.eclipse.paho.client.mqttv3;
}
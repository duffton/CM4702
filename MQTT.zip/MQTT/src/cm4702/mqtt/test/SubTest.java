package cm4702.mqtt.test;

import java.util.*;

import org.eclipse.paho.client.mqttv3.*;
import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;
import org.eclipse.paho.client.mqttv3.MqttException;
import org.eclipse.paho.client.mqttv3.MqttMessage;


/**
 * A simple subscriber using MQTT Paho.
 * This class implements the MqttCallback interface.
 *
 * @author K. Hui
 *
 */
public class SubTest implements MqttCallback {
public static void main(String[] args)
{
String topic = "heatingsystem"; //topic
int qos = 0; //QOS
String host = "tcp://node02.myqtthub.com:1883";//MQTT server URI ***MODIFY THIS***
String clientId = "pythonSub"; //client ID
String username = "pilogin";  //client username
String password = "ph5yVnQ1-kOOdGRoj";  //client password
char[] pw = "ph5yVnQ1-kOOdGRoj".toCharArray();

try {
 MqttClient client = new MqttClient(host, clientId);
 MqttConnectOptions connOpts = new MqttConnectOptions();
 connOpts.setCleanSession(true);
 connOpts.setUserName(username);
 connOpts.setPassword(pw);
 
 client.setCallback(new SubTest());
 System.out.println("Connecting to host: "+host);
 client.connect(connOpts);
 System.out.println("Subscribing topic: "+topic);
 client.subscribe(topic,qos);
} catch(MqttException me)
{
 System.out.println("reason "+me.getReasonCode());
 System.out.println("msg "+me.getMessage());
 System.out.println("loc "+me.getLocalizedMessage());
 System.out.println("cause "+me.getCause());
 System.out.println("excep "+me);
 me.printStackTrace();
}
catch (Exception e)
{
e.printStackTrace();
}
} //end method
/**
 * Method to invoke when connection is lost.
 */
@Override
public void connectionLost(Throwable cause) {
System.out.println("Connection lost.");
} //end method
/**
 * Method to invoke when a message is received.
 */
@Override
public void messageArrived(String topic, MqttMessage message) throws
Exception {
System.out.println("Topic: "+topic+" Message: "+message);

} //end method
/**
 * Method to invoke when message delivery is completed.
 */
@Override
public void deliveryComplete(IMqttDeliveryToken token) {
System.out.println("Delivery completed.");
} //end method
} //end class

